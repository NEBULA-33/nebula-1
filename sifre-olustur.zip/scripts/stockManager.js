// scripts/stockManager.js
import { state, saveData } from './dataManager.js';
import { renderAll } from './uiManager.js';
import { showMessage } from './utils.js'; // Ortak mesaj fonksiyonunu kullanıyoruz

let uiElements;
let currentStockInScans = []; // Bu modülün kendi içinde tuttuğu geçici bir durum

// Barkod/PLU kodundan ürün bulan yardımcı fonksiyon
function findProductByCode(code) {
    if (code.startsWith('28') && code.length >= 12) {
        const pluCode = code.substring(2, 7);
        const weightInGrams = parseInt(code.substring(7, 12));
        const product = state.products.find(p => p.isWeighable && p.pluCodes && p.pluCodes.includes(pluCode));
        if (product) {
            return { product, quantity: weightInGrams / 1000.0 };
        }
    } else {
        const product = state.products.find(p => !p.isWeighable && p.barcode === code);
        if (product) {
            return { product, quantity: 1 };
        }
    }
    return null;
}

// Stok giriş listesine ürün ekler
function addScanToStockInList(product, quantity) {
    currentStockInScans.push({ id: product.id, name: product.name, quantity: quantity, timestamp: new Date().toISOString() });
    renderAll(); // Arayüzü güncellemek için ana render fonksiyonunu çağır
    showMessage(uiElements.stockInMessage, `Listeye eklendi: ${product.name}`, 'success');
}

// Form gönderildiğinde stok girişini yönetir
function handleStockInScan(e) {
    e.preventDefault();
    const code = uiElements.stockInBarcodeScanInput.value.trim();
    if (!code) return;

    const result = findProductByCode(code);
    if (result) {
        addScanToStockInList(result.product, result.quantity);
    } else {
        showMessage(uiElements.stockInMessage, 'Bu koda sahip ürün bulunamadı!', 'error');
    }
    e.target.reset(); // Formu temizle
    uiElements.stockInBarcodeScanInput.focus();
}

// Stok giriş listesini onaylar ve ana stoklara ekler
function confirmStockIn() {
    if (currentStockInScans.length === 0) return;
    if (!confirm('Giriş listesindeki tüm ürünleri stoklara eklemek istediğinizden emin misiniz?')) return;

    currentStockInScans.forEach(scan => {
        const productInStock = state.products.find(p => p.id === scan.id);
        if (productInStock) {
            productInStock.stock += scan.quantity;
        }
    });

    currentStockInScans = []; // Geçici listeyi temizle
    saveData(); // Değişiklikleri kaydet
    renderAll(); // Arayüzü güncelle
    alert('Stok girişi başarıyla tamamlandı!');
}

// Fire/Zayiat formunu yönetir
function handleWastageSubmit(e) {
    e.preventDefault();
    const productId = uiElements.wastageProductSelect.value;
    const quantity = parseFloat(uiElements.wastageQuantityInput.value);
    const reason = uiElements.wastageReasonInput.value.trim();

    if (!productId || !quantity || quantity <= 0 || !reason) {
        return showMessage(uiElements.wastageMessage, 'Lütfen tüm alanları doldurun.', 'error');
    }
    const product = state.products.find(p => p.id == productId);
    if (!product || product.stock < quantity) {
        return showMessage(uiElements.wastageMessage, 'Geçersiz ürün veya yetersiz stok!', 'error');
    }

    product.stock -= quantity;
    saveData();
    renderAll();
    e.target.reset();
    showMessage(uiElements.wastageMessage, 'Ürün stoktan düşüldü.', 'success');
}

// İade formunu yönetir
function handleReturnSubmit(e) {
    e.preventDefault();
    const productId = uiElements.returnProductSelect.value;
    const quantity = parseFloat(uiElements.returnQuantityInput.value);
    
    if (!productId || !quantity || quantity <= 0) {
        return showMessage(uiElements.returnMessage, 'Lütfen ürün seçin ve miktar girin.', 'error');
    }
    const product = state.products.find(p => p.id == productId);
    if (!product) return;

    product.stock += quantity; // Stoğu geri ekle
    // İadeyi negatif bir satış olarak kaydet
    state.sales.push({
        productId: product.id,
        productName: product.name,
        quantity: -quantity, // İade olduğu için eksi
        sellingPrice: product.sellingPrice,
        totalRevenue: -(product.sellingPrice * quantity),
        date: new Date().toISOString(),
        isReturn: true
    });
    saveData();
    renderAll();
    e.target.reset();
    showMessage(uiElements.returnMessage, 'İade işlemi başarılı.', 'success');
}

// Bu fonksiyon, uiManager tarafından geçici listeyi okumak için kullanılır
export function getCurrentStockInScans() {
    return currentStockInScans;
}

// Modülü başlatan ana fonksiyon
export function initializeStockManager(elements) {
    uiElements = elements;
    // Olay dinleyicilerini ekle
    uiElements.stockInForm.addEventListener('submit', handleStockInScan);
    uiElements.confirmStockInBtn.addEventListener('click', confirmStockIn);
    uiElements.wastageForm.addEventListener('submit', handleWastageSubmit);
    uiElements.returnForm.addEventListener('submit', handleReturnSubmit);
    console.log("Stock Manager başlatıldı.");
}