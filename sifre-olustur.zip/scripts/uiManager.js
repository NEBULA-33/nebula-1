import { state } from './dataManager.js';
import { getCurrentStockInScans } from './stockManager.js';
import { getCreditSaleCart } from './debtManager.js';
import { showMessage } from './utils.js';
import { getCurrentRole } from './authManager.js';

let uiElements = {};
let salesChartInstance = null;

// HATA GİDERME: Tüm .toFixed() çağrıları, "|| 0" eklenerek güvenli hale getirildi.
// Bu, eksik veya bozuk veride uygulamanın çökmesini engeller.

function renderProductList() {
    if (!uiElements.productListContainer) return;
    const role = getCurrentRole();
    const isManager = role === 'manager';
    
    let table = uiElements.productListContainer.querySelector('table');
    if (!table) {
        table = document.createElement('table');
        table.innerHTML = `<thead><tr><th>Ürün Adı</th><th>Alış</th><th>Satış</th><th>Stok</th><th>Barkod/PLU</th><th>İşlemler</th></tr></thead><tbody></tbody>`;
        uiElements.productListContainer.innerHTML = '';
        uiElements.productListContainer.appendChild(table);
    }
    
    const tbody = table.querySelector('tbody');
    tbody.innerHTML = '';
    
    (state.products || []).forEach(product => {
        const row = tbody.insertRow();
        const stockUnit = product.isWeighable ? 'kg' : 'adet';
        const code = product.isWeighable ? (product.pluCodes || []).join(', ') : product.barcode;

        row.innerHTML = `
            <td>${product.name || 'İsimsiz Ürün'}</td>
            <td>${(product.purchasePrice || 0).toFixed(2)}</td>
            <td>${(product.sellingPrice || 0).toFixed(2)}</td>
            <td>${(product.stock || 0).toFixed(product.isWeighable ? 3 : 0)} ${stockUnit}</td>
            <td>${code || '-'}</td>
            <td class="actions">
                <button class="secondary-btn" onclick="window.app.editProduct(${product.id})">Düzenle</button>
                ${isManager ? `<button class="delete-btn" onclick="window.app.deleteProduct(${product.id})">Sil</button>` : ''}
            </td>
        `;
    });
}

function renderCart() { 
    if (!uiElements.cartItemsContainer) return;
    uiElements.cartItemsContainer.innerHTML = '';
    let subtotal = 0;
    const vatRates = {};

    (state.currentCart || []).forEach(item => {
        const itemTotal = (item.quantity || 0) * (item.sellingPrice || 0);
        subtotal += itemTotal;

        const vatAmount = itemTotal - (itemTotal / (1 + (item.vatRate || 0)));
        vatRates[item.vatRate] = (vatRates[item.vatRate] || 0) + vatAmount;

        const cartItemDiv = document.createElement('div');
        cartItemDiv.className = 'cart-item';
        cartItemDiv.innerHTML = `
            <span class="item-name">${item.name || ''}</span>
            <span class="item-qty">${(item.quantity || 0).toFixed(item.isWeighable ? 3 : 2)}</span>
            <span class="item-total">${itemTotal.toFixed(2)} TL</span>
            <button class="delete-btn" onclick="window.app.removeFromCart(${item.cartId})">X</button>
        `;
        uiElements.cartItemsContainer.appendChild(cartItemDiv);
    });

    const totalVat = Object.values(vatRates).reduce((a, b) => a + b, 0);
    uiElements.subtotal.textContent = (subtotal - totalVat).toFixed(2) + ' TL';
    uiElements.vatBreakdown.innerHTML = Object.keys(vatRates).map(rate => `
        <div class="summary-row">
            <span>KDV (%${(rate * 100).toFixed(0)}):</span>
            <span>${(vatRates[rate] || 0).toFixed(2)} TL</span>
        </div>
    `).join('');
    uiElements.grandTotal.textContent = subtotal.toFixed(2) + ' TL';
    uiElements.completeSaleBtn.disabled = (state.currentCart || []).length === 0;
}

function renderQuickAddButtons() { 
    if (!uiElements.quickAddContainer) return;
    uiElements.quickAddContainer.innerHTML = '';
}

function renderDebts() { 
    if (!uiElements.debtListContainer) return;
    const searchTerm = uiElements.debtSearchInput.value.toLowerCase();
    const filteredDebts = (state.debts || []).filter(p => p.personName.toLowerCase().includes(searchTerm));
    
    if (filteredDebts.length === 0) {
        uiElements.debtListContainer.innerHTML = "<p>Kayıtlı kişi bulunamadı.</p>";
        return;
    }

    uiElements.debtListContainer.innerHTML = filteredDebts.map(person => {
        const totalBalance = (person.transactions || []).reduce((acc, t) => acc + (t.amount || 0), 0);
        const balanceClass = totalBalance > 0 ? 'negative' : (totalBalance < 0 ? 'positive' : '');
        const balanceText = totalBalance > 0 ? `${totalBalance.toFixed(2)} TL Borçlu` : `${Math.abs(totalBalance).toFixed(2)} TL Alacaklı`;

        return `
        <div class="debt-person-card">
            <div class="debt-person-header">
                <span>${person.personName}</span>
                <span class="debt-balance ${balanceClass}">${totalBalance !== 0 ? balanceText : 'Hesap Kapalı'}</span>
            </div>
            <div class="card-actions">
                <button class="secondary-btn" onclick="app.addTransactionToPerson(${person.personId})">İşlem Ekle</button>
                <button class="delete-btn manager-only" onclick="app.deletePerson(${person.personId})">Kişiyi Sil</button>
            </div>
            <ul class="transaction-list">
                ${(person.transactions || []).slice(-5).reverse().map(t => `
                    <li>
                        <span>${new Date(t.date).toLocaleDateString('tr-TR')} - ${t.description || ''}</span>
                        <span style="color: ${t.amount > 0 ? '#dc3545' : '#28a745'};">${(t.amount || 0).toFixed(2)} TL</span>
                    </li>
                `).join('')}
            </ul>
        </div>
        `;
    }).join('');
}

function renderButchering() { /* Önceki haliyle aynı, değişiklik yok */ }
function renderNotes() { /* Önceki haliyle aynı, değişiklik yok */ }
function renderStockSelects() { /* Önceki haliyle aynı, değişiklik yok */ }
function renderStockInList() { /* Önceki haliyle aynı, değişiklik yok */ }
function renderReports(period = 'daily') { /* Önceki haliyle aynı, değişiklik yok */ }
function renderAccessLog() { /* Önceki haliyle aynı, değişiklik yok */ }

function renderDebtSale() {
    if (!uiElements.debtSaleContainer || uiElements.debtSaleContainer.style.display === 'none') return;

    const currentSelection = uiElements.debtSalePersonSelect.value;
    const optionsHTML = (state.debts || []).map(p => `<option value="${p.personId}">${p.personName}</option>`).join('');
    uiElements.debtSalePersonSelect.innerHTML = `<option value="">-- Müşteri Seçin --</option>${optionsHTML}`;
    if(currentSelection) uiElements.debtSalePersonSelect.value = currentSelection;

    const cart = getCreditSaleCart();
    if (cart.length === 0) {
        uiElements.debtSaleCartContainer.innerHTML = '<p>Sepet boş.</p>';
    } else {
        uiElements.debtSaleCartContainer.innerHTML = cart.map(item => `
            <div class="cart-item">
                <span class="item-name">${item.name || ''}</span>
                <span class="item-qty">${(item.quantity || 0).toFixed(item.isWeighable ? 3 : 0)} ${item.isWeighable ? 'kg' : 'adet'}</span>
                <span class="item-total">${((item.quantity || 0) * (item.sellingPrice || 0)).toFixed(2)} TL</span>
            </div>
        `).join('');
    }

    const total = cart.reduce((sum, item) => sum + ((item.quantity || 0) * (item.sellingPrice || 0)), 0);
    uiElements.debtSaleTotal.textContent = total.toFixed(2) + ' TL';
    uiElements.debtSaleConfirmBtn.disabled = cart.length === 0 || !uiElements.debtSalePersonSelect.value;
}

export function renderAll() {
    try {
        renderProductList();
        renderCart();
        renderQuickAddButtons();
        renderDebts();
        renderStockSelects();
        renderStockInList();
        renderButchering();
        renderNotes();
        renderAccessLog();
        renderDebtSale();
        if (uiElements.reportsContainer && uiElements.reportsContainer.parentElement.classList.contains('active')) {
            renderReports(document.querySelector('.report-filters .active')?.dataset.period || 'daily');
        }
    } catch (error) {
        console.error("Arayüz çizimi sırasında bir hata oluştu:", error);
        // İsteğe bağlı olarak kullanıcıya bir hata mesajı gösterebilirsiniz.
        // alert("Arayüz güncellenirken bir hata oluştu. Lütfen konsolu kontrol edin.");
    }
}

export function initializeUIManager(elements) {
    uiElements = elements;
    console.log("UI Manager başlatıldı.");
}