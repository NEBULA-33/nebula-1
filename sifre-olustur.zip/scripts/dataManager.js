// HATA DÜZELTMESİ: 'state' objesi 'export const' ile dışarıya açılıyor.
export const state = {
    products: [],
    sales: [],
    debts: [],
personalNotes: [], 
    butcheringRecipes: [],
accessLog: [],
    currentCart: [],
    currentStockInScans: [],
    logs: {
        stockIn: [],
        wastage: [],
        butchering: []
    }
};

const STORAGE_KEY = 'businessDataV3_Stable';

export function saveData() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (error) {
        console.error("Veri kaydedilirken hata oluştu:", error);
    }
}

export function loadData() {
    try {
        const savedData = localStorage.getItem(STORAGE_KEY);
        if (savedData) {
            Object.assign(state, JSON.parse(savedData));
        }
    } catch (error) {
        console.error("Veri yüklenirken hata oluştu:", error);
    }
}

export function exportData() {
    const dataStr = JSON.stringify(state, null, 2);
    const dataBlob = new Blob([dataStr], { type: "application/json" });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    const date = new Date();
    const dateStr = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`;
    link.download = `isletme_asistani_yedek_${dateStr}.json`;
    link.href = url;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    alert('Tüm verileriniz başarıyla yedeklendi!');
}

export function importData(event, onImportSuccess) {
    const file = event.target.files[0];
    if (!file) return;
    if (!confirm('UYARI: Bu işlem mevcut tüm verilerinizi, seçtiğiniz yedek dosyasındaki verilerle değiştirecektir. Emin misiniz?')) {
        event.target.value = '';
        return;
    }
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const importedData = JSON.parse(e.target.result);
            if (importedData.products && importedData.sales) {
                Object.assign(state, importedData);
                saveData();
                alert('Veriler başarıyla geri yüklendi!');
                if (onImportSuccess) onImportSuccess();
            } else {
                alert('Hata: Seçilen dosya geçerli bir yedek dosyası değil.');
            }
        } catch (error) {
            alert(`Hata: Dosya okunurken bir sorun oluştu. ${error.message}`);
        } finally {
            event.target.value = '';
        }
    };
    reader.readAsText(file);
}

export function initializeDataManager() {
    loadData();
    console.log("Data Manager başlatıldı ve veriler yüklendi.");
}