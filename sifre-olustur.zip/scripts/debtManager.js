import { state, saveData } from './dataManager.js';
import { renderAll } from './uiManager.js';
import { showMessage } from './utils.js';

let uiElements;
let creditSaleCart = []; // Veresiye satışı için geçici sepet

// --- YENİ FONKSİYONLAR: VERESİYE SATIŞ İÇİN ---

// Ürünü barkodla bulup veresiye sepetine ekler
function handleDebtSaleScan(e) {
    e.preventDefault();
    const scannedCode = uiElements.debtSaleBarcodeScan.value.trim();
    if (!scannedCode) return;

    let productToSell = null;
    let quantity = 1;

    // Tartılabilir ürün kontrolü
    if (scannedCode.startsWith('28') && scannedCode.length >= 12) {
        const pluCode = scannedCode.substring(2, 7);
        const weightInGrams = parseInt(scannedCode.substring(7, 12));
        if (!isNaN(weightInGrams)) {
            productToSell = state.products.find(p => p.isWeighable && p.pluCodes.includes(pluCode));
            quantity = weightInGrams / 1000.0;
        }
    } else {
        productToSell = state.products.find(p => !p.isWeighable && p.barcode === scannedCode);
    }

    if (productToSell) {
        if (productToSell.stock < quantity) {
            showMessage(uiElements.debtSaleMessage, `Stok yetersiz! Mevcut: ${productToSell.stock.toFixed(3)}`, 'error');
        } else {
            const existingItem = creditSaleCart.find(item => item.id === productToSell.id);
            if (existingItem) {
                existingItem.quantity += quantity;
            } else {
                creditSaleCart.push({ ...productToSell, quantity });
            }
            showMessage(uiElements.debtSaleMessage, `${productToSell.name} sepete eklendi.`, 'success');
        }
    } else {
        showMessage(uiElements.debtSaleMessage, 'Bu barkoda sahip ürün bulunamadı!', 'error');
    }
    
    uiElements.debtSaleForm.reset();
    renderAll();
}

// Veresiye sepetini temizler
function clearDebtSaleCart() {
    creditSaleCart = [];
    renderAll();
}

// Sepeti seçili kişinin borcuna ekler
function confirmDebtSale() {
    const personId = parseInt(uiElements.debtSalePersonSelect.value);
    if (!personId) {
        showMessage(uiElements.debtSaleMessage, 'Lütfen borç eklenecek bir müşteri seçin.', 'error');
        return;
    }
    if (creditSaleCart.length === 0) {
        showMessage(uiElements.debtSaleMessage, 'Sepet boş.', 'error');
        return;
    }

    const person = state.debts.find(p => p.personId === personId);
    if (!person) {
        showMessage(uiElements.debtSaleMessage, 'Müşteri bulunamadı.', 'error');
        return;
    }

    // Toplam tutarı ve açıklamayı oluştur
    const totalAmount = creditSaleCart.reduce((sum, item) => sum + (item.sellingPrice * item.quantity), 0);
    const productNames = creditSaleCart.map(item => item.name).join(', ');
    const description = `Alışveriş: ${productNames}`;

    // Yeni işlemi kişinin borçlarına ekle
    person.transactions.push({
        id: Date.now(),
        date: new Date().toISOString(),
        amount: totalAmount, // Borç olduğu için pozitif
        description
    });

    // Stokları düşür
    creditSaleCart.forEach(cartItem => {
        const productInStock = state.products.find(p => p.id === cartItem.id);
        if (productInStock) {
            productInStock.stock -= cartItem.quantity;
        }
    });

    saveData();
    clearDebtSaleCart();
    showMessage(uiElements.debtSaleMessage, `${person.personName} adlı kişinin borcuna ${totalAmount.toFixed(2)} TL eklendi.`, 'success');
    renderAll();
}

// --- MEVCUT FONKSİYONLAR ---
function resetDebtForm() {
    if (uiElements.debtForm) uiElements.debtForm.reset();
    if (uiElements.debtPersonId) uiElements.debtPersonId.value = '';
    if (uiElements.debtPersonName) uiElements.debtPersonName.readOnly = false;
    if (uiElements.debtSubmitButton) uiElements.debtSubmitButton.textContent = 'Kaydet';
}

function handleDebtFormSubmit(e) {
    e.preventDefault();
    const personId = uiElements.debtPersonId.value ? parseInt(uiElements.debtPersonId.value) : null;
    const personName = uiElements.debtPersonName.value.trim();
    const amount = parseFloat(uiElements.debtAmount.value);
    const description = uiElements.debtDescription.value.trim();

    if (!personName || isNaN(amount) || !description) {
        alert("Lütfen tüm alanları geçerli bir şekilde doldurun.");
        return;
    }

    let person = personId ? state.debts.find(p => p.personId === personId) : state.debts.find(p => p.personName.toLowerCase() === personName.toLowerCase());

    if (person && !personId) {
        alert("Bu isimde bir kişi zaten mevcut. Lütfen arama yapıp listeden işlem ekleyin veya farklı bir isim kullanın.");
        return;
    }
    
    const newTransaction = { id: Date.now(), date: new Date().toISOString(), amount, description };

    if (person) {
        person.transactions.push(newTransaction);
    } else {
        state.debts.push({ personId: Date.now(), personName, transactions: [newTransaction] });
    }
    saveData();
    renderAll();
    resetDebtForm();
}

export function addTransactionToPerson(personId) {
    const person = state.debts.find(p => p.personId === personId);
    if (!person) return;
    uiElements.debtPersonId.value = person.personId;
    uiElements.debtPersonName.value = person.personName;
    uiElements.debtPersonName.readOnly = true;
    uiElements.debtSubmitButton.textContent = `${person.personName} için İşlem Kaydet`;
    if(uiElements.debtAmount) uiElements.debtAmount.focus();
}

export function deletePerson(personId) {
    const person = state.debts.find(p => p.personId === personId);
    if (!person) return;
    if (confirm(`'${person.personName}' adlı kişiyi ve tüm geçmişini silmek istediğinize emin misiniz?`)) {
        state.debts = state.debts.filter(p => p.personId !== personId);
        saveData();
        renderAll();
    }
}

export function getCreditSaleCart() {
    return creditSaleCart;
}

export function initializeDebtManager(elements) {
    uiElements = elements;
    window.app = window.app || {};
    window.app.addTransactionToPerson = addTransactionToPerson;
    window.app.deletePerson = deletePerson;

    if (uiElements.debtForm) {
        uiElements.debtForm.addEventListener('submit', handleDebtFormSubmit);
    }
    if (uiElements.debtSearchInput) {
        uiElements.debtSearchInput.addEventListener('input', () => renderAll());
    }
    if (uiElements.clearDebtFormButton) {
        uiElements.clearDebtFormButton.addEventListener('click', resetDebtForm);
    }

    // YENİ OLAY DİNLEYİCİLERİ
    if(uiElements.debtSaleForm) {
        uiElements.debtSaleForm.addEventListener('submit', handleDebtSaleScan);
    }
    if(uiElements.debtSaleConfirmBtn) {
        uiElements.debtSaleConfirmBtn.addEventListener('click', confirmDebtSale);
    }
    if(uiElements.debtSaleClearBtn) {
        uiElements.debtSaleClearBtn.addEventListener('click', clearDebtSaleCart);
    }

    console.log("Debt Manager başlatıldı.");
}