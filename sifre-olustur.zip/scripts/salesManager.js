import { state, saveData } from './dataManager.js';
import { renderAll } from './uiManager.js';

let uiElements = {};

export function addToCart(product, quantity) {
    if (!product || quantity <= 0) return;
    if (product.stock < quantity) {
        alert(`Stokta yeterli ürün yok! Mevcut stok: ${product.stock}`);
        return;
    }
    if (!product.isWeighable) {
        const existingItem = state.currentCart.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            state.currentCart.push({ ...product, quantity, cartId: Date.now() });
        }
    } else {
        state.currentCart.push({ ...product, quantity, cartId: Date.now() });
    }
    renderAll();
}

export function removeFromCart(cartId) {
    state.currentCart = state.currentCart.filter(item => item.cartId !== cartId);
    renderAll();
}

export function clearCart() {
    state.currentCart = [];
    renderAll();
}

export function completeSale() {
    if (state.currentCart.length === 0) return;
    const saleTimestamp = new Date().toISOString();
    state.currentCart.forEach(cartItem => {
        state.sales.push({
            productId: cartItem.id,
            productName: cartItem.name,
            quantity: cartItem.quantity,
            purchasePrice: cartItem.purchasePrice,
            sellingPrice: cartItem.sellingPrice,
            totalRevenue: cartItem.sellingPrice * cartItem.quantity,
            date: saleTimestamp,
            vatRate: cartItem.vatRate
        });
        const productInStock = state.products.find(p => p.id === cartItem.id);
        if (productInStock) {
            productInStock.stock -= cartItem.quantity;
        }
    });
    saveData();
    clearCart();
    alert('Satış başarıyla tamamlandı!');
}

function handleBarcodeSell(e) {
    e.preventDefault();
    const scannedCode = uiElements.barcodeScanInput.value.trim();
    if (!scannedCode) return;
    let productToSell = null;
    let quantity = 1;
    if (scannedCode.startsWith('28') && scannedCode.length >= 12) {
        const pluCode = scannedCode.substring(2, 7);
        const weightInGrams = parseInt(scannedCode.substring(7, 12));
        if (!isNaN(weightInGrams)) {
            productToSell = state.products.find(p => p.isWeighable && p.pluCodes.includes(pluCode));
            quantity = weightInGrams / 1000.0;
        }
    } else {
        productToSell = state.products.find(p => !p.isWeighable && p.barcode === scannedCode);
    }
    if (productToSell) {
        addToCart(productToSell, quantity);
    } else {
        alert('Bu barkoda sahip bir ürün bulunamadı!');
    }
    uiElements.barcodeScanInput.value = '';
    uiElements.barcodeScanInput.focus();
}

export function initializeSalesManager(elements) {
    uiElements = elements;
    window.app = window.app || {};
    window.app.addToCart = addToCart;
    window.app.removeFromCart = removeFromCart;
    if (uiElements.barcodeSellForm) uiElements.barcodeSellForm.addEventListener('submit', handleBarcodeSell);
    if (uiElements.completeSaleBtn) uiElements.completeSaleBtn.addEventListener('click', completeSale);
    if (uiElements.clearCartBtn) uiElements.clearCartBtn.addEventListener('click', clearCart);
    console.log("Sales Manager başlatıldı.");
}