// scripts/butcheringManager.js
import { state, saveData } from './dataManager.js';
import { renderAll } from './uiManager.js';
import { showMessage } from './utils.js';

let uiElements = {};

// --- AKILLI ÜRÜN BULMA FONKSİYONU ---
function findProductByCode(code) {
    if (code.startsWith('28') && code.length >= 12) {
        const pluCode = code.substring(2, 7);
        return state.products.find(p => p.isWeighable && p.pluCodes && p.pluCodes.includes(pluCode));
    } else {
        return state.products.find(p => !p.isWeighable && p.barcode === code);
    }
}

// --- BARKOD OKUMA MANTIĞI ---
function handleSourceProductScan(e) {
    const barcode = e.target.value.trim();
    if (!barcode) {
        uiElements.scannedSourceProductName.textContent = '';
        uiElements.butcherRecipeSelect.innerHTML = '<option value="">-- Önce Ürün Okutun --</option>';
        uiElements.butcherRecipeSelect.disabled = true;
        return;
    }

    const product = findProductByCode(barcode);

    if (product) {
        uiElements.scannedSourceProductName.textContent = `Seçilen Ürün: ${product.name}`;
        const filteredRecipes = state.butcheringRecipes.filter(r => r.sourceProductId === product.id);
        
        if (filteredRecipes.length > 0) {
            const recipesOptions = filteredRecipes.map(r => `<option value="${r.id}">${r.name}</option>`).join('');
            uiElements.butcherRecipeSelect.innerHTML = `<option value="">-- Reçete Seç --</option>${recipesOptions}`;
            uiElements.butcherRecipeSelect.disabled = false;
            showMessage(uiElements.butcherMessage, `${product.name} seçildi. Şimdi reçete seçin.`, 'success');
        } else {
            uiElements.butcherRecipeSelect.innerHTML = '<option value="">-- Reçete Bulunamadı --</option>';
            uiElements.butcherRecipeSelect.disabled = true;
            showMessage(uiElements.butcherMessage, 'Bu ürüne ait reçete bulunamadı!', 'error');
        }
    } else {
        uiElements.scannedSourceProductName.textContent = '';
        uiElements.butcherRecipeSelect.innerHTML = '<option value="">-- Önce Ürün Okutun --</option>';
        uiElements.butcherRecipeSelect.disabled = true;
        showMessage(uiElements.butcherMessage, 'Bu barkoda/PLU\'ya sahip ürün bulunamadı!', 'error');
    }
}

// --- REÇETE İŞLEMLERİ ---

// BU FONKSİYON SORUNU ÇÖZMEK İÇİN YENİDEN YAZILDI
function addRecipeOutputLine(productId = '', percentage = '') {
    if (!uiElements.recipeOutputsContainer) return;
    
    const line = document.createElement('div');
    line.className = 'recipe-output-line';

    // Ürün seçme menüsünü oluştur
    const productSelect = document.createElement('select');
    productSelect.className = 'recipe-output-product';
    
    // Başlangıç seçeneği
    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = '-- Çıktı Ürünü Seç --';
    productSelect.appendChild(defaultOption);

    // Tüm ürünleri listeye ekle (daha sağlam yöntem)
    state.products.forEach(p => {
        const option = document.createElement('option');
        option.value = p.id;
        option.textContent = p.name;
        productSelect.appendChild(option);
    });
    
    productSelect.value = productId; // Eğer düzenleme modundaysa eski değeri seç

    // Oran giriş alanını oluştur
    const percentageInput = document.createElement('input');
    percentageInput.type = 'number';
    percentageInput.className = 'recipe-output-percentage';
    percentageInput.placeholder = 'Oran %';
    percentageInput.step = '0.01';
    percentageInput.value = percentage;

    // Silme butonunu oluştur
    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'delete-btn';
    removeBtn.textContent = 'X';
    removeBtn.onclick = () => line.remove();

    // Hepsini satıra ekle ve sayfaya yansıt
    line.append(productSelect, percentageInput, removeBtn);
    uiElements.recipeOutputsContainer.appendChild(line);
}


function resetRecipeForm() {
    if (uiElements.butcheringRecipeForm) uiElements.butcheringRecipeForm.reset();
    if (uiElements.editRecipeId) uiElements.editRecipeId.value = '';
    if (uiElements.recipeOutputsContainer) uiElements.recipeOutputsContainer.innerHTML = '';
    if (state.products.length > 0) {
        addRecipeOutputLine();
    }
    if (uiElements.saveRecipeBtn) uiElements.saveRecipeBtn.textContent = 'Reçeteyi Kaydet';
    if (uiElements.cancelRecipeEditBtn) uiElements.cancelRecipeEditBtn.style.display = 'none';
}

function handleRecipeSave(e) {
    e.preventDefault();
    const recipeId = parseInt(uiElements.editRecipeId.value) || null;
    const recipeName = uiElements.recipeName.value.trim();
    const sourceProductId = parseInt(uiElements.recipeSourceProduct.value);
    if (!recipeName || !sourceProductId) {
        alert('Reçete adı ve kaynak ürün seçilmelidir.');
        return;
    }
    const outputs = [];
    let totalPercentage = 0;
    uiElements.recipeOutputsContainer.querySelectorAll('.recipe-output-line').forEach(line => {
        const productId = parseInt(line.querySelector('.recipe-output-product').value);
        const percentage = parseFloat(line.querySelector('.recipe-output-percentage').value);
        if (productId && percentage > 0) {
            outputs.push({ productId, percentage });
            totalPercentage += percentage;
        }
    });
    if (outputs.length === 0) {
        alert('En az bir geçerli çıktı ürünü eklemelisiniz.');
        return;
    }
    if (totalPercentage > 100.01) {
        alert(`Toplam oran %100'ü geçemez! Sizin toplamınız: %${totalPercentage.toFixed(2)}`);
        return;
    }
    const recipeData = { name: recipeName, sourceProductId, outputs };
    if (recipeId) {
        const recipeIndex = state.butcheringRecipes.findIndex(r => r.id === recipeId);
        if (recipeIndex > -1) {
            state.butcheringRecipes[recipeIndex] = { ...state.butcheringRecipes[recipeIndex], ...recipeData };
        }
    } else {
        recipeData.id = Date.now();
        state.butcheringRecipes.push(recipeData);
    }
    saveData();
    renderAll();
    resetRecipeForm();
}

function editRecipe(id) {
    const recipe = state.butcheringRecipes.find(r => r.id === id);
    if (!recipe) return;
    resetRecipeForm();
    uiElements.editRecipeId.value = recipe.id;
    uiElements.recipeName.value = recipe.name;
    uiElements.recipeSourceProduct.value = recipe.sourceProductId;
    uiElements.recipeOutputsContainer.innerHTML = '';
    recipe.outputs.forEach(output => addRecipeOutputLine(output.productId, output.percentage));
    uiElements.saveRecipeBtn.textContent = 'Reçeteyi Güncelle';
    uiElements.cancelRecipeEditBtn.style.display = 'inline-block';
}

function deleteRecipe(id) {
    if (confirm("Bu reçeteyi silmek istediğinizden emin misiniz?")) {
        state.butcheringRecipes = state.butcheringRecipes.filter(r => r.id !== id);
        saveData();
        renderAll();
    }
}

function executeButchering(e) {
    e.preventDefault();
    const product = findProductByCode(uiElements.butcherSourceScanInput.value.trim());
    if (!product) {
        showMessage(uiElements.butcherMessage, 'Lütfen önce geçerli bir ana ürün okutun.', 'error');
        return;
    }
    const recipeId = parseInt(uiElements.butcherRecipeSelect.value);
    const quantity = parseFloat(uiElements.butcherQuantityInput.value);
    if (!recipeId || !quantity || quantity <= 0) {
        showMessage(uiElements.butcherMessage, 'Lütfen geçerli bir reçete ve miktar girin.', 'error');
        return;
    }
    const recipe = state.butcheringRecipes.find(r => r.id === recipeId);
    const sourceProductInState = state.products.find(p => p.id === product.id);
    if (sourceProductInState.stock < quantity) {
        showMessage(uiElements.butcherMessage, `Ana ürün için yeterli stok yok! (Stok: ${sourceProductInState.stock})`, 'error');
        return;
    }
    sourceProductInState.stock -= quantity;
    recipe.outputs.forEach(output => {
        const outputProduct = state.products.find(p => p.id === output.productId);
        if (outputProduct) {
            const addedQuantity = quantity * (output.percentage / 100);
            outputProduct.stock += addedQuantity;
        }
    });
    if (!state.logs.butchering) {
        state.logs.butchering = [];
    }
    state.logs.butchering.push({ recipeId: recipe.id, recipeName: recipe.name, sourceQuantity: quantity, date: new Date().toISOString() });
    saveData();
    renderAll();
    showMessage(uiElements.butcherMessage, 'Parçalama işlemi başarıyla tamamlandı!', 'success');
    uiElements.executeButcheringForm.reset();
    uiElements.scannedSourceProductName.textContent = '';
    uiElements.butcherRecipeSelect.innerHTML = '<option value="">-- Önce Ürün Okutun --</option>';
    uiElements.butcherRecipeSelect.disabled = true;
}

export function initializeButcheringManager(elements) {
    uiElements = elements;
    window.app = window.app || {};
    window.app.editRecipe = editRecipe;
    window.app.deleteRecipe = deleteRecipe;
    if (uiElements.butcherSourceScanInput) {
        uiElements.butcherSourceScanInput.addEventListener('change', handleSourceProductScan);
    }
    if (uiElements.addRecipeOutputBtn) {
        uiElements.addRecipeOutputBtn.addEventListener('click', () => addRecipeOutputLine());
    }
    if (uiElements.butcheringRecipeForm) {
        uiElements.butcheringRecipeForm.addEventListener('submit', handleRecipeSave);
    }
    if (uiElements.cancelRecipeEditBtn) {
        uiElements.cancelRecipeEditBtn.addEventListener('click', resetRecipeForm);
    }
    if (uiElements.executeButcheringForm) {
        uiElements.executeButcheringForm.addEventListener('submit', executeButchering);
    }
    resetRecipeForm();
    console.log("Butchering Manager başlatıldı.");
}