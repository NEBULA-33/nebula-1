// scripts/notesManager.js
import { state, saveData } from './dataManager.js';
import { renderAll } from './uiManager.js';

let uiElements = {};

function handleNoteSubmit(e) {
    e.preventDefault();
    const content = uiElements.noteContent.value.trim();
    if (!content) return;

    const newNote = {
        id: Date.now(),
        content: content,
        createdDate: new Date().toISOString()
    };

    state.personalNotes.unshift(newNote); // Notu en başa ekle
    saveData();
    renderAll();
    e.target.reset();
}

function deleteNote(id) {
    if (confirm("Bu notu silmek istediğinizden emin misiniz?")) {
        state.personalNotes = state.personalNotes.filter(note => note.id !== id);
        saveData();
        renderAll();
    }
}

export function initializeNotesManager(elements) {
    uiElements = elements;
    window.app = window.app || {};
    window.app.deleteNote = deleteNote; // Silme fonksiyonunu global'e taşı

    if (uiElements.noteForm) {
        uiElements.noteForm.addEventListener('submit', handleNoteSubmit);
    }
    console.log("Notes Manager başlatıldı.");
}