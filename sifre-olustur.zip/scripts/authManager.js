import { state, saveData } from './dataManager.js';

let uiElements = {};
let currentUserRole = null;

const MANAGER_PASSWORD_HASH = '03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4';

async function hashText(text) {
    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export function applyRolePermissions() {
    const role = getCurrentRole();

    // 1. Önce her şeyi varsayılan olarak "yönetici görebilir" durumuna getir.
    // Tüm sekmeler ve formlar görünür olsun.
    document.querySelectorAll('.hidden-by-role').forEach(el => el.classList.remove('hidden-by-role'));
    document.querySelectorAll('.manager-only').forEach(el => el.style.display = 'block');
    
    // 2. Eğer rol "Kasiyer" ise, kısıtlamaları uygula.
    if (role === 'cashier') {
        // Yöneticiye özel panelleri gizle
        document.querySelectorAll('.manager-only').forEach(el => el.style.display = 'none');

        // Kasiyerin görmemesi gereken sekmeleri gizle
        const hiddenTabsForCashier = ['debts-notes', 'reports', 'settings'];
        hiddenTabsForCashier.forEach(tabName => {
            const tabButton = uiElements.tabs.querySelector(`[data-tab="${tabName}"]`);
            if (tabButton) tabButton.classList.add('hidden-by-role');
        });

        // Kasiyerin stok düşümü ve iade formlarını gizle
        if (uiElements.wastageFormContainer) uiElements.wastageFormContainer.classList.add('hidden-by-role');
        if (uiElements.returnFormContainer) uiElements.returnFormContainer.classList.add('hidden-by-role');
        
        // Gerekirse varsayılan sekmeye geç
        const activeTab = document.querySelector('.tab-btn.active');
        if (activeTab && activeTab.classList.contains('hidden-by-role')) {
            const firstVisibleTab = document.querySelector('.tab-btn:not(.hidden-by-role)');
            if (firstVisibleTab) firstVisibleTab.click();
        }
    }
}


function logAccess(role, status) {
    if (!state.accessLog) state.accessLog = [];
    state.accessLog.unshift({ role, status, timestamp: new Date().toISOString() });
    if (state.accessLog.length > 50) state.accessLog.pop();
    saveData();
}

function login(role, onLoginSuccess) {
    currentUserRole = role;
    sessionStorage.setItem('currentUserRole', role);
    if (uiElements.loginOverlay) uiElements.loginOverlay.style.display = 'none';
    if (uiElements.mainContainer) uiElements.mainContainer.style.display = 'flex';
    onLoginSuccess();
}

async function handleManagerLoginAttempt(e, onLoginSuccess) {
    e.preventDefault();
    const password = uiElements.managerPasswordInput.value;
    const hashedInput = await hashText(password);
    if (hashedInput === MANAGER_PASSWORD_HASH) {
        logAccess('manager', 'başarılı');
        login('manager', onLoginSuccess);
    } else {
        logAccess('manager', 'başarısız');
        uiElements.passwordErrorMessage.textContent = 'Hatalı şifre!';
        uiElements.passwordErrorMessage.style.display = 'block';
    }
}

function showManagerLogin() {
    if (uiElements.roleSelection) uiElements.roleSelection.classList.add('hidden-by-role');
    if (uiElements.managerLoginForm) uiElements.managerLoginForm.classList.remove('hidden-by-role');
    if (uiElements.managerPasswordInput) uiElements.managerPasswordInput.focus();
}

function showRoleSelection() {
    if (uiElements.roleSelection) uiElements.roleSelection.classList.remove('hidden-by-role');
    if (uiElements.managerLoginForm) uiElements.managerLoginForm.classList.add('hidden-by-role');
    if (uiElements.passwordErrorMessage) uiElements.passwordErrorMessage.style.display = 'none';
    if (uiElements.managerPasswordInput) uiElements.managerPasswordInput.value = '';
}

function logout() {
    sessionStorage.removeItem('currentUserRole');
    location.reload();
}

export function getCurrentRole() {
    return currentUserRole;
}

export function initializeAuthManager(elements, onLogin) {
    uiElements = elements;
    if (uiElements.logoutBtn) uiElements.logoutBtn.addEventListener('click', logout);
    if (uiElements.showManagerLoginBtn) uiElements.showManagerLoginBtn.addEventListener('click', showManagerLogin);
    if (uiElements.loginCashierBtn) {
        uiElements.loginCashierBtn.addEventListener('click', () => {
            logAccess('cashier', 'başarılı');
            login('cashier', onLogin);
        });
    }
    if (uiElements.managerLoginForm) {
        uiElements.managerLoginForm.addEventListener('submit', (e) => handleManagerLoginAttempt(e, onLogin));
    }
    if (uiElements.cancelManagerLoginBtn) {
        uiElements.cancelManagerLoginBtn.addEventListener('click', showRoleSelection);
    }
    const savedRole = sessionStorage.getItem('currentUserRole');
    if (savedRole) {
        login(savedRole, onLogin);
    } else {
        if (uiElements.loginOverlay) uiElements.loginOverlay.style.display = 'flex';
    }
    console.log("Auth Manager başlatıldı.");
}