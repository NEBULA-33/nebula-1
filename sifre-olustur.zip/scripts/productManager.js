// scripts/productManager.js
import { state, saveData } from './dataManager.js';
import { renderAll } from './uiManager.js';
import { getCurrentRole } from './authManager.js'; // Rol bilgisini almak için import ediyoruz

let uiElements = {};

function resetProductForm() {
    if (uiElements.productForm) uiElements.productForm.reset();
    if (uiElements.editProductIdInput) uiElements.editProductIdInput.value = '';
    if (uiElements.pluCodesContainer) uiElements.pluCodesContainer.innerHTML = '';
    if (uiElements.productSubmitBtn) uiElements.productSubmitBtn.textContent = 'Ürünü Ekle';
    if (uiElements.cancelEditBtn) uiElements.cancelEditBtn.style.display = 'none';

    // Form sıfırlandığında tüm alanların tekrar yazılabilir olduğundan emin ol
    const fieldsToToggle = [
        uiElements.purchasePriceInput,
        uiElements.sellingPriceInput,
        uiElements.stockQuantityInput
    ];
    fieldsToToggle.forEach(field => {
        if(field) {
            field.readOnly = false;
            field.disabled = false;
        }
    });

    toggleProductFields();
}

function toggleProductFields() {
    if (!uiElements.isWeighableCheckbox || !uiElements.pluSection || !uiElements.barcodeSection) return;
    if (uiElements.isWeighableCheckbox.checked) {
        uiElements.pluSection.style.display = 'block';
        uiElements.barcodeSection.style.display = 'none';
        if (uiElements.pluCodesContainer && uiElements.pluCodesContainer.children.length === 0) {
            addPluInput();
        }
    } else {
        uiElements.pluSection.style.display = 'none';
        uiElements.barcodeSection.style.display = 'block';
    }
}

function addPluInput(value = '') {
    if (!uiElements.pluCodesContainer) return;
    const group = document.createElement('div');
    group.className = 'plu-input-group';
    group.innerHTML = `<input type="text" class="plu-code-input" placeholder="5 haneli PLU kodu" value="${value}"><button type="button" class="delete-btn">Sil</button>`;
    group.querySelector('.delete-btn').onclick = () => group.remove();
    uiElements.pluCodesContainer.appendChild(group);
}

function handleProductFormSubmit(e) {
    e.preventDefault();
    const editingId = parseInt(uiElements.editProductIdInput.value);
    const pluInputs = uiElements.pluCodesContainer.querySelectorAll('.plu-code-input');
    const pluCodes = Array.from(pluInputs).map(input => input.value.trim()).filter(Boolean);
    const productData = {
        name: uiElements.productNameInput.value.trim(),
        isWeighable: uiElements.isWeighableCheckbox.checked,
        pluCodes,
        barcode: uiElements.productBarcodeInput.value.trim(),
        vatRate: parseFloat(uiElements.productVatRateSelect.value),
        purchasePrice: parseFloat(uiElements.purchasePriceInput.value),
        sellingPrice: parseFloat(uiElements.sellingPriceInput.value),
        stock: parseFloat(uiElements.stockQuantityInput.value) || 0
    };
    if (editingId) {
        const productIndex = state.products.findIndex(p => p.id === editingId);
        if (productIndex > -1) {
            const existingProduct = state.products[productIndex];
            Object.assign(existingProduct, { ...productData, stock: parseFloat(uiElements.stockQuantityInput.value) });
        }
    } else {
        productData.id = Date.now();
        state.products.push(productData);
    }
    saveData();
    renderAll();
    resetProductForm();
}

function editProduct(id) {
    const product = state.products.find(p => p.id === id);
    if (!product) return;
    
    resetProductForm();
    
    // Formu doldur
    uiElements.editProductIdInput.value = product.id;
    uiElements.productNameInput.value = product.name;
    uiElements.isWeighableCheckbox.checked = product.isWeighable;
    uiElements.productBarcodeInput.value = product.barcode || '';
    uiElements.productVatRateSelect.value = product.vatRate;
    uiElements.purchasePriceInput.value = product.purchasePrice;
    uiElements.sellingPriceInput.value = product.sellingPrice;
    uiElements.stockQuantityInput.value = product.stock;
    
    if (product.isWeighable && product.pluCodes) {
        product.pluCodes.forEach(code => addPluInput(code));
    }
    
    toggleProductFields();

    // --- KASİYER YETKİ KONTROLÜ BURADA ---
    const role = getCurrentRole();
    const isManager = (role === 'manager');

    // Sadece yönetici fiyatları ve stoğu değiştirebilsin
    // disabled = true hem alanı gri yapar hem de veri göndermesini engeller.
    uiElements.purchasePriceInput.disabled = !isManager;
    uiElements.sellingPriceInput.disabled = !isManager;
    uiElements.stockQuantityInput.disabled = !isManager;
    
    uiElements.productSubmitBtn.textContent = 'Ürünü Güncelle';
    uiElements.cancelEditBtn.style.display = 'inline-block';
    if (uiElements.productForm) uiElements.productForm.scrollIntoView({ behavior: 'smooth' });
}

function deleteProduct(id) {
    const productName = state.products.find(p => p.id === id)?.name || 'Bu ürün';
    if (confirm(`'${productName}' adlı ürünü kalıcı olarak silmek istediğinizden emin misiniz?`)) {
        state.products = state.products.filter(p => p.id !== id);
        saveData();
        renderAll();
    }
}

export function initializeProductManager(elements) {
    uiElements = elements;
    window.app = window.app || {};
    window.app.editProduct = editProduct;
    window.app.deleteProduct = deleteProduct;
    if (uiElements.productForm) uiElements.productForm.addEventListener('submit', handleProductFormSubmit);
    if (uiElements.isWeighableCheckbox) uiElements.isWeighableCheckbox.addEventListener('change', toggleProductFields);
    if (uiElements.addPluBtn) uiElements.addPluBtn.addEventListener('click', () => addPluInput());
    if (uiElements.cancelEditBtn) uiElements.cancelEditBtn.addEventListener('click', resetProductForm);
    toggleProductFields();
    console.log("Product Manager başlatıldı.");
}