// scripts/reportsManager.js
import { renderAll } from './uiManager.js'; // Raporları uiManager çizecek, biz sadece tetikleyeceğiz

let uiElements;

// Rapor filtresi butonlarına tıklandığında çalışır
function handleFilterClick(e) {
    if (e.target.tagName === 'BUTTON' && e.target.classList.contains('filter-btn')) {
        // Aktif butonu güncelle
        uiElements.reportFilters.querySelector('.active').classList.remove('active');
        e.target.classList.add('active');
        
        // Ana render fonksiyonunu çağırarak tüm arayüzü,
        // yeni seçilen periyoda göre yeniden çizdir.
        renderAll();
    }
}

export function initializeReportsManager(elements) {
    uiElements = elements;
    uiElements.reportFilters.addEventListener('click', handleFilterClick);
    console.log("Reports Manager başlatıldı.");
}