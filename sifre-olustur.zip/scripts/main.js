import { initializeDataManager, importData, exportData } from './dataManager.js';
import { initializeUIManager, renderAll } from './uiManager.js';
import { initializeAuthManager, applyRolePermissions } from './authManager.js';
import { initializeProductManager } from './productManager.js';
import { initializeSalesManager } from './salesManager.js';
import { initializeStockManager } from './stockManager.js';
import { initializeDebtManager } from './debtManager.js';
import { initializeReportsManager } from './reportsManager.js';
import { initializeButcheringManager } from './butcheringManager.js';
import { initializeNotesManager } from './notesManager.js';

document.addEventListener('DOMContentLoaded', () => {
    console.log("Uygulama konteyneri yüklendi...");

    const uiElements = {
        // Giriş ve Ana Yapı
        loginOverlay: document.getElementById('login-overlay'),
        mainContainer: document.querySelector('.main-container'),
        logoutBtn: document.getElementById('logout-btn'),
        roleSelection: document.getElementById('role-selection'),
        showManagerLoginBtn: document.getElementById('show-manager-login-btn'),
        loginCashierBtn: document.getElementById('login-cashier-btn'),
        managerLoginForm: document.getElementById('manager-login-form'),
        managerPasswordInput: document.getElementById('manager-password'),
        cancelManagerLoginBtn: document.getElementById('cancel-manager-login-btn'),
        passwordErrorMessage: document.getElementById('password-error-message'),
        
        // Sekmeler
        tabs: document.querySelector('.tabs'),
        
        // Satış ve Sepet
        salesMessage: document.getElementById('sales-message'),
        barcodeSellForm: document.getElementById('barcode-sell-form'),
        barcodeScanInput: document.getElementById('barcode-scan-input'),
        quickAddContainer: document.getElementById('quick-add-container'),
        cartItemsContainer: document.getElementById('cart-items-container'),
        subtotal: document.getElementById('subtotal'),
        vatBreakdown: document.getElementById('vat-breakdown'),
        grandTotal: document.getElementById('grand-total'),
        completeSaleBtn: document.getElementById('complete-sale-btn'),
        clearCartBtn: document.getElementById('clear-cart-btn'),
        
        // Ürün Yönetimi
        productListContainer: document.getElementById('product-list-container'),
        productForm: document.getElementById('product-form'),
        editProductIdInput: document.getElementById('edit-product-id'),
        productNameInput: document.getElementById('product-name'),
        productVatRateSelect: document.getElementById('product-vat-rate'),
        isWeighableCheckbox: document.getElementById('is-weighable'),
        pluSection: document.getElementById('plu-section'),
        barcodeSection: document.getElementById('barcode-section'),
        pluCodesContainer: document.getElementById('plu-codes-container'),
        addPluBtn: document.getElementById('add-plu-btn'),
        productBarcodeInput: document.getElementById('product-barcode'),
        purchasePriceInput: document.getElementById('purchase-price'),
        sellingPriceInput: document.getElementById('selling-price'),
        stockQuantityInput: document.getElementById('stock-quantity'),
        productSubmitBtn: document.getElementById('product-submit-btn'),
        cancelEditBtn: document.getElementById('cancel-edit-btn'),

        // Stok İşlemleri
        stockInForm: document.getElementById('stock-in-form'),
        stockInBarcodeScanInput: document.getElementById('stock-in-barcode-scan-input'),
        stockInListContainer: document.getElementById('stock-in-list-container'),
        confirmStockInBtn: document.getElementById('confirm-stock-in-btn'),
        stockInMessage: document.getElementById('stock-in-message'),
        wastageForm: document.getElementById('wastage-form'),
        wastageFormContainer: document.getElementById('wastage-form').parentElement,
        wastageProductSelect: document.getElementById('wastage-product-select'),
        wastageQuantityInput: document.getElementById('wastage-quantity-input'),
        wastageReasonInput: document.getElementById('wastage-reason-input'),
        wastageMessage: document.getElementById('wastage-message'),
        returnForm: document.getElementById('return-form'),
        returnFormContainer: document.getElementById('return-form').parentElement,
        returnProductSelect: document.getElementById('return-product-select'),
        returnQuantityInput: document.getElementById('return-quantity-input'),
        returnMessage: document.getElementById('return-message'),

        // Veresiye ve Notlar
        subTabsContainer: document.querySelector('.sub-tabs'),
        debtForm: document.getElementById('debt-form'),
        debtPersonId: document.getElementById('debt-person-id'),
        debtPersonName: document.getElementById('debt-person-name'),
        debtAmount: document.getElementById('debt-amount'),
        debtDescription: document.getElementById('debt-description'),
        debtSubmitButton: document.getElementById('debt-submit-button'),
        clearDebtFormButton: document.getElementById('clear-debt-form-button'),
        debtSearchInput: document.getElementById('debt-search-input'),
        debtListContainer: document.getElementById('debt-list-container'),
        debtSaleContainer: document.getElementById('debt-sale-container'),
        debtSalePersonSelect: document.getElementById('debt-sale-person-select'),
        debtSaleForm: document.getElementById('debt-sale-form'),
        debtSaleBarcodeScan: document.getElementById('debt-sale-barcode-scan'),
        debtSaleCartContainer: document.getElementById('debt-sale-cart-container'),
        debtSaleTotal: document.getElementById('debt-sale-total'),
        debtSaleConfirmBtn: document.getElementById('debt-sale-confirm-btn'),
        debtSaleClearBtn: document.getElementById('debt-sale-clear-btn'),
        debtSaleMessage: document.getElementById('debt-sale-message'),
        noteForm: document.getElementById('note-form'),
        noteContent: document.getElementById('note-content'),
        noteListContainer: document.getElementById('note-list-container'),
        
        // Raporlar
        reportsTab: document.querySelector('[data-tab="reports"]'), // DÜZELTİLDİ
        reportFilters: document.querySelector('.report-filters'),
        reportPeriodTitle: document.getElementById('report-period-title'),
        summaryRevenue: document.getElementById('summary-revenue'),
        summaryProfit: document.getElementById('summary-profit'),
        summaryItemsSold: document.getElementById('summary-items-sold'),
        salesChart: document.getElementById('sales-chart'),
        reportsContainer: document.getElementById('reports-container'),

        // Parçalama
        butcheringTab: document.querySelector('[data-tab="butchering"]'), // DÜZELTİLDİ
        butcheringRecipeForm: document.getElementById('butchering-recipe-form'),
        editRecipeId: document.getElementById('edit-recipe-id'),
        recipeName: document.getElementById('recipe-name'),
        recipeSourceProduct: document.getElementById('recipe-source-product'),
        recipeOutputsContainer: document.getElementById('recipe-outputs-container'),
        addRecipeOutputBtn: document.getElementById('add-recipe-output-btn'),
        saveRecipeBtn: document.getElementById('save-recipe-btn'),
        cancelRecipeEditBtn: document.getElementById('cancel-recipe-edit-btn'),
        executeButcheringForm: document.getElementById('execute-butchering-form'),
        butcherRecipeSelect: document.getElementById('butcher-recipe-select'),
        butcherQuantityInput: document.getElementById('butcher-quantity-input'),
        butcherMessage: document.getElementById('butcher-message'),
        recipeListContainer: document.getElementById('recipe-list-container'),
        butcherSourceScanInput: document.getElementById('butcher-source-scan-input'),
        scannedSourceProductName: document.getElementById('scanned-source-product-name'),
        
        // Ayarlar
        settingsTab: document.querySelector('[data-tab="settings"]'), // DÜZELTİLDİ
        exportDataBtn: document.getElementById('export-data-btn'),
        importDataBtn: document.getElementById('import-data-btn'),
        importFileInput: document.getElementById('import-file-input'),
        accessLogContainer: document.getElementById('access-log-container'),
    };

    initializeDataManager(); 

    function startApp() {
        console.log('UI Elements:', uiElements);
        console.log("Giriş başarılı. Arayüz başlatılıyor...");
        
        initializeUIManager(uiElements);
        initializeProductManager(uiElements);
        initializeSalesManager(uiElements);
        initializeStockManager(uiElements);
        initializeDebtManager(uiElements);
        initializeReportsManager(uiElements);
        initializeButcheringManager(uiElements);
        initializeNotesManager(uiElements);

        uiElements.tabs.addEventListener('click', (e) => {
            const target = e.target;
            if (target.tagName === 'BUTTON' && target.dataset.tab && !target.classList.contains('active')) {
                if(target.classList.contains('hidden-by-role')) return;
                const currentActiveTab = uiElements.tabs.querySelector('.active');
                if(currentActiveTab) {
                    document.getElementById(currentActiveTab.dataset.tab)?.classList.remove('active');
                    currentActiveTab.classList.remove('active');
                }
                target.classList.add('active');
                document.getElementById(target.dataset.tab)?.classList.add('active');
            }
        });

        if (uiElements.subTabsContainer) {
            uiElements.subTabsContainer.addEventListener('click', (e) => {
                if (e.target.tagName === 'BUTTON' && e.target.dataset.subtab) {
                    uiElements.subTabsContainer.querySelector('.active').classList.remove('active');
                    e.target.classList.add('active');
                    document.querySelectorAll('.sub-tab-content').forEach(content => content.classList.remove('active'));
                    document.getElementById(e.target.dataset.subtab).classList.add('active');
                }
            });
        }
        
        uiElements.exportDataBtn.addEventListener('click', exportData);
        uiElements.importDataBtn.addEventListener('click', () => uiElements.importFileInput.click());
        uiElements.importFileInput.addEventListener('change', (e) => importData(e, renderAll));
        
        renderAll();
        applyRolePermissions();
        
        if (uiElements.barcodeScanInput) {
            uiElements.barcodeScanInput.focus();
        }
        console.log("Arayüz başarıyla başlatıldı.");
    }

    initializeAuthManager(uiElements, startApp);
});